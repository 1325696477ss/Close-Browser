document.addEventListener('DOMContentLoaded', function () {
    const timeDisplay = document.getElementById('timeDisplay');
    const minutesInput = document.getElementById('minutes');
    const secondsInput = document.getElementById('seconds');
    const minutesPreset = document.getElementById('minutesPreset');
    const secondsPreset = document.getElementById('secondsPreset');
    const startBtn = document.getElementById('startBtn');
    const resetBtn = document.getElementById('resetBtn');

    let popupCountdownInterval;
    let totalSeconds = 0;

    // 加载时检查是否有正在进行的倒计时
    chrome.runtime.sendMessage({ action: "getCountdownStatus" }, response => {
        if (response.isRunning && response.remainingSeconds > 0) {
            totalSeconds = response.remainingSeconds;
            updateDisplay(totalSeconds);
            startPopupCountdown();
            startBtn.disabled = true;

            // 同步警告状态
            updateWarningStyle(totalSeconds);
            // 禁用所有输入元素
            disableElements.forEach(el => el.disabled = true);
        }
    });

    // 获取所有需要禁用的元素
    const disableElements = [
        minutesInput,
        secondsInput,
        minutesPreset,
        secondsPreset
    ];


    // 预设选择器事件 - 修复NaN问题
    minutesPreset.addEventListener('change', function () {
        if (this.value) {
            minutesInput.value = parseInt(this.value) || 0;
            updateDisplayFromInputs();
        }
    });

    secondsPreset.addEventListener('change', function () {
        if (this.value) {
            secondsInput.value = parseInt(this.value) || 0;
            updateDisplayFromInputs();
        }
    });

    // 输入变化时更新显示
    minutesInput.addEventListener('input', updateDisplayFromInputs);
    secondsInput.addEventListener('input', updateDisplayFromInputs);

    // 从输入框更新显示
    function updateDisplayFromInputs() {
        const minutes = parseInt(minutesInput.value) || 0;
        const seconds = parseInt(secondsInput.value) || 0;
        totalSeconds = minutes * 60 + seconds;
        updateDisplay(totalSeconds);
    }

    // 更新显示
    function updateDisplay(seconds) {
        const displayMinutes = Math.floor(seconds / 60);
        const displaySeconds = seconds % 60;
        timeDisplay.textContent =
            `${displayMinutes.toString().padStart(2, '0')}:${displaySeconds.toString().padStart(2, '0')}`;
    }

    // 更新警告样式
    function updateWarningStyle(seconds) {
        if (seconds <= 60) {
            timeDisplay.classList.add('warning');
        } else {
            timeDisplay.classList.remove('warning');
        }
    }

    // 开始按钮事件
    startBtn.addEventListener('click', function () {
        const minutes = parseInt(minutesInput.value) || 0;
        const seconds = parseInt(secondsInput.value) || 0;
        totalSeconds = minutes * 60 + seconds;
        if (totalSeconds <= 0) {
            // swal("错误", "请设置大于0的时间", "error");
            // swal({
            //     title: "错误",
            //     text: "请设置大于0的时间",
            //     type: "error",
            //     customClass: "small-popup"
            // });
            return;
        }

        // 发送消息给后台开始倒计时
        chrome.runtime.sendMessage({
            action: "startCountdown",
            totalSeconds: totalSeconds
        }, response => {
            if (response && response.success) {
                startPopupCountdown();
                startBtn.disabled = true;
                updateWarningStyle(totalSeconds);
            }
        });
        disableElements.forEach(el => el.disabled = true);

    });

    // 重置按钮事件
    resetBtn.addEventListener('click', function () {
        // 发送消息给后台停止倒计时
        chrome.runtime.sendMessage({ action: "stopCountdown" }, response => {
            if (response && response.success) {
                clearInterval(popupCountdownInterval);
                popupCountdownInterval = null;
                minutesInput.value = '0';
                secondsInput.value = '0';
                minutesPreset.value = '';
                secondsPreset.value = '';
                totalSeconds = 0;
                updateDisplay(0);
                startBtn.disabled = false;
                timeDisplay.classList.remove('warning');
                // 重新启用所有输入元素
                disableElements.forEach(el => el.disabled = false);
            }
        });
    });

    // 开始弹出窗口的倒计时显示
    function startPopupCountdown() {
        if (popupCountdownInterval) {
            clearInterval(popupCountdownInterval);
        }

        popupCountdownInterval = setInterval(function () {
            chrome.runtime.sendMessage({ action: "getCountdownStatus" }, response => {
                if (response && response.isRunning && response.remainingSeconds > 0) {
                    totalSeconds = response.remainingSeconds;
                    updateDisplay(totalSeconds);
                    updateWarningStyle(totalSeconds);
                } else {
                    // 倒计时已结束
                    clearInterval(popupCountdownInterval);
                    timeDisplay.textContent = '00:00';
                    startBtn.disabled = false;
                    timeDisplay.classList.remove('warning');

                    // 重新启用所有输入元素
                    disableElements.forEach(el => el.disabled = false);

                    // 自动关闭窗口
                    if (response && !response.isRunning) {
                        chrome.runtime.sendMessage({ action: "closeWindow" });
                    }
                }
            });
        }, 200); // 更新频率提高到200ms以获得更流畅的体验
    }

    // 初始化显示
    updateDisplay(0);
});