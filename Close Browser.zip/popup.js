document.addEventListener('DOMContentLoaded', function () {
    const STORAGE_KEY = 'countdown_data';
    const timeDisplay = document.getElementById('timeDisplay');
    const minutesInput = document.getElementById('minutes');
    const secondsInput = document.getElementById('seconds');
    const minutesPreset = document.getElementById('minutesPreset');
    const secondsPreset = document.getElementById('secondsPreset');
    const startBtn = document.getElementById('startBtn');
    const resetBtn = document.getElementById('resetBtn');

    let popupCountdownInterval;
    let totalSeconds = 0;
    const disableElements = [minutesInput, secondsInput, minutesPreset, secondsPreset];


    // 初始化检查倒计时状态
    async function initCountdown() {
        try {
            // 先尝试从后台获取状态
            const response = await new Promise(resolve => {
                chrome.runtime.sendMessage(
                    { action: "getCountdownStatus" },
                    response => resolve(response || {})
                );
            });

            if (response.isRunning && response.remainingSeconds > 0) {
                // 后台有运行的倒计时
                totalSeconds = response.remainingSeconds;
                updateUI(true);
            } else {
                // 检查存储中的状态
                const data = await chrome.storage.local.get(STORAGE_KEY);
                if (data[STORAGE_KEY] && data[STORAGE_KEY].isRunning) {
                    const elapsed = Math.floor((Date.now() - data[STORAGE_KEY].timestamp) / 1000);
                    totalSeconds = Math.max(0, data[STORAGE_KEY].remainingSeconds - elapsed);

                    if (totalSeconds > 0) {
                        // 恢复倒计时
                        chrome.runtime.sendMessage({
                            action: "startCountdown",
                            totalSeconds: totalSeconds
                        });
                        updateUI(true);
                    }
                }
            }
        } catch (error) {
            console.error('初始化倒计时错误:', error);
        }
    }


    // 更新UI状态
    function updateUI(isRunning) {
        updateDisplay(totalSeconds);
        if (!isRunning) {
            timeDisplay.classList.remove('warning');  // 非运行状态确保黑色
        } else {
            updateWarningStyle(totalSeconds);
        }
        startBtn.disabled = isRunning;
        disableElements.forEach(el => el.disabled = isRunning);

        if (isRunning) {
            startPopupCountdown();
        } else if (popupCountdownInterval) {
            clearInterval(popupCountdownInterval);
        }
    }


    // 更新显示
    function updateDisplay(seconds) {
        const displayMinutes = Math.floor(seconds / 60);
        const displaySeconds = seconds % 60;
        timeDisplay.textContent =
            `${displayMinutes.toString().padStart(2, '0')}:${displaySeconds.toString().padStart(2, '0')}`;
    }


    // 更新警告样式
    function updateWarningStyle(seconds) {
        timeDisplay.classList.toggle('warning', seconds <= 60);
    }


    // 从输入框更新显示
    function updateDisplayFromInputs() {
        const minutes = parseInt(minutesInput.value) || 0;
        const seconds = parseInt(secondsInput.value) || 0;
        totalSeconds = minutes * 60 + seconds;
        updateDisplay(totalSeconds);
    }


    // 开始弹出窗口的倒计时显示
    function startPopupCountdown() {
        clearInterval(popupCountdownInterval);

        popupCountdownInterval = setInterval(async () => {
            try {
                const response = await new Promise(resolve => {
                    chrome.runtime.sendMessage(
                        { action: "getCountdownStatus" },
                        response => resolve(response || {})
                    );
                });

                if (response.isRunning && response.remainingSeconds > 0) {
                    totalSeconds = response.remainingSeconds;
                    updateDisplay(totalSeconds);
                    updateWarningStyle(totalSeconds);
                } else {
                    clearInterval(popupCountdownInterval);
                    timeDisplay.textContent = '00:00';
                    updateUI(false);

                    if (!response.isRunning) {
                        chrome.runtime.sendMessage({ action: "closeWindow" });
                    }
                }
            } catch (error) {
                console.error('倒计时更新错误:', error);
            }
        }, 200);
    }


    // 事件监听
    minutesPreset.addEventListener('change', function () {
        if (this.value) {
            minutesInput.value = parseInt(this.value) || 0;
            updateDisplayFromInputs();
        }
    });

    secondsPreset.addEventListener('change', function () {
        if (this.value) {
            secondsInput.value = parseInt(this.value) || 0;
            updateDisplayFromInputs();
        }
    });

    minutesInput.addEventListener('input', updateDisplayFromInputs);
    secondsInput.addEventListener('input', updateDisplayFromInputs);


    // startBtn
    startBtn.addEventListener('click', async function () {
        const minutes = parseInt(minutesInput.value) || 0;
        const seconds = parseInt(secondsInput.value) || 0;
        totalSeconds = minutes * 60 + seconds;

        if (totalSeconds <= 0) {
            return;
        }

        const response = await new Promise(resolve => {
            chrome.runtime.sendMessage(
                { action: "startCountdown", totalSeconds: totalSeconds },
                response => resolve(response || {})
            );
        });

        if (response.success) {
            updateUI(true);
        }
    });


    // resetBtn
    resetBtn.addEventListener('click', async function () {
        const response = await new Promise(resolve => {
            chrome.runtime.sendMessage(
                { action: "stopCountdown" },
                response => resolve(response || {})
            );
        });

        if (response.success) {
            minutesInput.value = '0';
            secondsInput.value = '0';
            minutesPreset.value = '';
            secondsPreset.value = '';
            totalSeconds = 0;
            updateUI(false);
        }
    });

    // 初始化
    initCountdown();
});