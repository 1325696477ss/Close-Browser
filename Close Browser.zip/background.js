const STORAGE_KEY = 'countdown_data';
let countdownInterval = null;
let remainingSeconds = 0;


// 保存倒计时状态到存储
async function saveCountdownState() {
    await chrome.storage.local.set({
        [STORAGE_KEY]: {
            remainingSeconds,
            isRunning: countdownInterval !== null,
            timestamp: Date.now()
        }
    });
}


// 关闭当前窗口（增强版）
function closeCurrentWindow() {
    chrome.windows.getCurrent(window => {
        if (window) {
            chrome.windows.remove(window.id).catch(error => {
                console.error('关闭窗口失败，尝试备用方法:', error);
                chrome.windows.getLastFocused({ populate: true }, lastWindow => {
                    if (lastWindow) chrome.windows.remove(lastWindow.id);
                });
            });
        } else {
            chrome.windows.getLastFocused({ populate: true }, lastWindow => {
                if (lastWindow) chrome.windows.remove(lastWindow.id);
            });
        }
    });
}


// 加载保存的状态
async function loadCountdownState() {
    const data = await chrome.storage.local.get(STORAGE_KEY);
    if (data[STORAGE_KEY]) {
        const { remainingSeconds: savedSeconds, isRunning, timestamp } = data[STORAGE_KEY];
        if (isRunning) {
            const elapsedSeconds = Math.floor((Date.now() - timestamp) / 1000);
            remainingSeconds = Math.max(0, savedSeconds - elapsedSeconds);

            if (remainingSeconds > 0) {
                startCountdown();
            } else {
                await chrome.storage.local.remove(STORAGE_KEY);
                closeCurrentWindow();
            }
        }
    }
}


// 启动倒计时
function startCountdown() {
    if (countdownInterval) {
        clearInterval(countdownInterval);
    }

    countdownInterval = setInterval(async () => {
        remainingSeconds--;
        await saveCountdownState();

        if (remainingSeconds <= 0) {
            clearInterval(countdownInterval);
            countdownInterval = null;
            await chrome.storage.local.remove(STORAGE_KEY);
            closeCurrentWindow();
        }
    }, 1000);
}

// 初始化时加载状态
loadCountdownState();

// 心跳检测防止后台挂起
setInterval(() => {
    if (countdownInterval) {
        saveCountdownState();
    }
}, 30000); // 每30秒保存一次状态


// 消息监听
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "startCountdown") {
        remainingSeconds = request.totalSeconds;
        startCountdown();
        sendResponse({ success: true });
    }
    else if (request.action === "getCountdownStatus") {
        sendResponse({
            remainingSeconds: remainingSeconds,
            isRunning: countdownInterval !== null
        });
    }
    else if (request.action === "stopCountdown") {
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
            remainingSeconds = 0;
            chrome.storage.local.remove(STORAGE_KEY);
        }
        sendResponse({ success: true });
    }
    else if (request.action === "closeWindow") {
        closeCurrentWindow();
    }

    return true;
});