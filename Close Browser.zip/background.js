// chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
//     if (request.action === "closeWindow") {
//         chrome.windows.getCurrent(window => {
//             if (window) chrome.windows.remove(window.id);
//         });
//         return true;
//     }
// });

let countdownInterval = null;
let remainingSeconds = 0;

function closeCurrentWindow() {
    chrome.windows.getCurrent(window => {
        if (window) {
            chrome.windows.remove(window.id);
        } else {
            // 如果无法获取当前窗口，尝试关闭最后一个活动窗口
            chrome.windows.getLastFocused(window => {
                if (window) chrome.windows.remove(window.id);
            });
        }
    });
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "startCountdown") {
        // 清除现有计时器
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
        }

        remainingSeconds = request.totalSeconds;

        countdownInterval = setInterval(() => {
            remainingSeconds--;

            if (remainingSeconds <= 0) {
                clearInterval(countdownInterval);
                countdownInterval = null;
                closeCurrentWindow();
            }
        }, 1000);

        sendResponse({ success: true });
    }
    else if (request.action === "getCountdownStatus") {
        sendResponse({
            remainingSeconds: remainingSeconds,
            isRunning: countdownInterval !== null
        });
    }
    else if (request.action === "stopCountdown") {
        if (countdownInterval) {
            clearInterval(countdownInterval);
            countdownInterval = null;
            remainingSeconds = 0;
        }
        sendResponse({ success: true });
    }
    else if (request.action === "closeWindow") {
        closeCurrentWindow();
    }

    return true; // 保持消息通道开放
});