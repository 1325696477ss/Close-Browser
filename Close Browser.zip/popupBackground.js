let countdownInterval;
let totalSeconds = 0;
let lastUpdateTime = 0;

// 处理来自popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "start") {
        totalSeconds = request.time;
        startCountdown();
    } else if (request.action === "getTime") {
        sendResponse({
            time: totalSeconds,
            lastUpdate: lastUpdateTime
        });
    } else if (request.action === "stop") {
        clearInterval(countdownInterval);
        totalSeconds = 0;
    }
});

function startCountdown() {
    clearInterval(countdownInterval);

    countdownInterval = setInterval(() => {
        if (totalSeconds <= 0) {
            clearInterval(countdownInterval);
            return;
        }

        totalSeconds--;
        lastUpdateTime = Date.now();

        // 通知所有打开的popup页面更新
        chrome.runtime.sendMessage({
            action: "update",
            time: totalSeconds
        });
    }, 1000);
}